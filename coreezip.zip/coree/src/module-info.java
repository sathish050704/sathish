/**
 * 
 */
/**
 * 
 */
module coree {
}