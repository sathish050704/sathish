package Searching;

public class linearclass {

public static void main(String[] args) {
	int[]arr= {5,3,8,4,2};
	int target=4;
	boolean found=false;
	for(int i=0;i<arr.length;i++) {
		if(arr[i]==target) {
		System.out.println("found at index:"+i);
		found=true;
		break;
		}	
	}

if(found) {
	System.out.println("not found");
	System.out.println("not found");
	
}
	
}
}
