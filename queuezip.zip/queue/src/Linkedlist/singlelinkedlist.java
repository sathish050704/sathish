package Linkedlist;

import java.security.DomainCombiner;

class Node {
int data;
 Node Next;
Node(int new_data){
	this.data=new_data;
	this.Next=null;
}
}
public class singlelinkedlist{
	public static void traveslist(Node head) {
		while(head!=null) {
			System.out.println(head.data +" ");
			
			head=head.Next;
		}	
		System.out.println( );		
	}
	public static void main(String[] args) {
		
		Node head=new Node(10);
		head.Next=new Node(20);
		head.Next.Next=new Node(30);
		head.Next.Next.Next=new Node(40);
		traveslist(head);
		
	}	
}





	

	
