package com;

public class classandobject {
 static String Company_Name="tcs";
 static String Company_location="hyd";
 String emp_name;
 int emp_id;
 int emp_salary;
 public static void developer(){
	 System.out.println("desigination is developer");
	 
 }
public void tester() {
System.out.println("desigination is tester");

}
public static void main(String[] args) {
	System.out.println("company_name");
	System.out.println("company_location");
	classandobject co=new classandobject();
	co.emp_name="ram";
	System.out.println(co.emp_name);
	co.emp_id=455;
	System.out.println(co.emp_id);
	co.emp_salary=25000;
	System.out.println(co.emp_salary);
	developer();
	System.out.println("______---");
	classandobject co1=new classandobject();
	System.out.println("company name");
	System.out.println("company location");
	co1.emp_name="sita";
	System.out.println(co1.emp_name);
	co1.emp_id=234;
	System.out.println(co1.emp_id);
	co1.emp_salary=100000;
	System.out.println(co1.emp_salary);
	developer();
	
}
}
