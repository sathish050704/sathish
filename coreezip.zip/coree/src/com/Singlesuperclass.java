package com;

public class Singlesuperclass {
int a;
int b;
public void display() {
	System.out.println(a);
	System.out.println(b);
	
}
public static void main (String[] args) {
	Singlesuperclass ss=new Singlesuperclass();
	ss.a=10;
	ss.b=20;
	ss.display();
	
	
	
	
}
}
