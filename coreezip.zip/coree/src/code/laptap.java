package code;

public class laptap {
private String name ;
private int RAM;
private String model;
private int ROM;
private int cost;
public laptap(String name, int rAM, String model, int rOM, int cost) {
	super();
	this.name = name;
	RAM = rAM;
	this.model = model;
	ROM = rOM;
	this.cost = cost;
}
public laptap() {
	super();
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getRAM() {
	return RAM;
}
public void setRAM(int rAM) {
	RAM = rAM;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public int getROM() {
	return ROM;
}
public void setROM(int rOM) {
	ROM = rOM;
}
public int getCost() {
	return cost;
}
public void setCost(int cost) {
	this.cost = cost;
}
public void display() {
	System.out.println("name of thr laptop :+getname");
	System.out.println("RAM :+get RAM");
	System.out.println("ROM :+getROM");
	System.out.println("model :+getmodel");
	System.out.println("cost :+getcost");

}
public void main(String[] args) {
	System.out.println("laptapdetails");
	laptap m=new laptap();
	m.setName("hp");
	m.setModel("micro");
	m.display();
	
	
}

}