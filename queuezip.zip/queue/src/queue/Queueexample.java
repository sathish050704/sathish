package queue;
import java.util.LinkedList;
import java.util.Queue;
public class Queueexample {
	public static void main(String[] args) {
		Queue<Integer>Queue=new LinkedList<>();
		Queue.add(10);
		Queue.add(20);
		Queue.add(30);
		
		System.out.println("queue:"+Queue);
		System.out.println("frontelement:"+Queue.peek());
		System.out.println("rempved:"+Queue.remove());
		System.out.println("queue after remove:"+Queue);
		System.out.println("polled:"+Queue.poll());
		System.out.println("queue after poll:"+Queue);
		System.out.println("size:"+Queue.size());
		System.out.println("is queue empty?"+Queue.isEmpty());
	}

}
