package level3;

public class testimplementsample {
	public void sample1() {
		System.out.println("sample block");
		
	}
	public static void main(String[] args) {
		testimplementsample t=new testimplementsample();
		t.sample1();
		
	}

}
