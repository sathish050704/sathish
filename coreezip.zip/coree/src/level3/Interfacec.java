package level3;

public class Interfacec {

}
