package MOVIE_TicketBook;
import java.util.Scanner;
public class ticket {
	static int availableTickets=100;
	public static String book(int Quantity) {
		
		if(Quantity<=0) {
			return"ticket quantity should be positive";
		}
		
		availableTickets -=Quantity;
		int totalamount=Quantity*50;
		return "successfully booked"+Quantity + "tickets.Total"+"cost:"+totalamount +".remaining tickets:"+availableTickets;
		
	}
public static String showavailabletickets() {
	return "available Tickets:" +availableTickets;
}
public static String cancelTickets(int Quantity) {
	if(Quantity<=0) {
		return"cancel quantity shoulb be positive";
		
	}else if(Quantity>(100-availableTickets)) {
		return"cannot cancel more tickets than booked";
			
	}
	availableTickets+=Quantity;
	return"successfully cancled"+Quantity+"tickets.Remainingtickets:"+availableTickets;
}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	while(true) {
		System.out.println("select the option:");
		System.out.println("1.book movie tickets");
		System.out.println("2.cancel tickets");
		System.out.println("3.show available tickets");
		System.out.println("4.exit");
		int option=sc.nextInt();
		switch(option) {
		case 1:
			System.out.println("enter the number of tickets to book:");
			int Quantity=sc.nextInt();
			System.out.println(book(Quantity));
			break;
		case 2:
			System.out.println("enter the number of tickets to cancel:");
			int quantity=sc.nextInt();
		case 3:
			System.out.println(showavailabletickets());
			break;
		case 4:
			System.out.println("thank you!exiting....");
			break;
			default:
				System.out.println("invalid option.....");
				
			
		
		}
}
	
	
	
}
}
