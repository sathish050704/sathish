package level3;

public class Interfacef  {
  void c() {
	  System.out.println("c");
	  
  }
  void d() {
	  System.out.println("d");
	  
  }
  void e() {
	  System.out.println("e");
	  
  }
  public static void main(String[] args){
	  Interfacef f=new Interfacef();
	  f.c();
	  f.d();
	  f.e();
	  
  }
}
