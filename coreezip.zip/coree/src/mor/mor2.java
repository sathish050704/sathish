package mor;

public class mor2 extends methodoverridding {
public void whatsappversions() {
	System.out.println("version2 has both single and doble ticks");
	
		
	}
	public static void main(String[] args) {
		mor2 m=new mor2();
		m.whatsappversions();
		
	}
	
}
