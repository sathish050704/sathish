package mor;

public class  methodoverridding {
	public void whatsappversions() {
		System.out.println("version 1->only SINGLE ticks");
		

		
		
		
	}
	
	

}
