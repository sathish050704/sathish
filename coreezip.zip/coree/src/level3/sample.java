package level3;

public interface sample {
 void sample1();
	 
 }
 

