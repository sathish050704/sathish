package com;

public class Classconstructor {
public void constructor() {
	System.out.println("hi students");
}
public void constructor(int a) {
	System.out.println("value is"+a);
	
}
public void constructor(int c,int d) {
	int res=c+d;
	System.out.println(res);
	
}
public static void main(String[] args) {
	Classconstructor sc=new Classconstructor();
	
	
	
}
}
